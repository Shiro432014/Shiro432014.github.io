import re
import torch
import logging

from scripts.animatediff_infotext import write_params_txt
from scripts.animatediff_ui import AnimateDiffProcess
from scripts.animatediff_mm import mm_animatediff as motion_module

logger = logging.getLogger("AnimateDiffPromptSchedule")


class AnimateDiffPromptSchedule:
    def __init__(self, p: "StableDiffusionProcessing", params: AnimateDiffProcess):
        self.prompt_map = None
        self.original_prompt = None
        self.parse_prompt(p, params)

    def save_infotext_img(self, p: "StableDiffusionProcessing"):
        """Restore original prompt for saving images."""
        if self.prompt_map is not None:
            p.prompts = [self.original_prompt for _ in range(p.batch_size)]

    def save_infotext_txt(self, res: "Processed"):
        """Restore original prompt for saving text infotext."""
        if self.prompt_map is not None and res.info is not None:
            parts = res.info.split('\nNegative prompt: ', 1)
            if len(parts) > 1:
                res.info = f"{self.original_prompt}\nNegative prompt: {parts[1]}"
            for i in range(len(res.infotexts)):
                parts = res.infotexts[i].split('\nNegative prompt: ', 1)
                if len(parts) > 1:
                    res.infotexts[i] = f"{self.original_prompt}\nNegative prompt: {parts[1]}"
            write_params_txt(res.info)

    def parse_prompt(self, p: "StableDiffusionProcessing", params: AnimateDiffProcess):
        """Parse prompt with optional prompt travel syntax (frame: prompt)."""
        if not isinstance(p.prompt, str):
            logger.warning("prompt is not str, cannot support prompt map")
            return

        lines = p.prompt.strip().split('\n')
        data = {'head_prompts': [], 'mapp_prompts': {}, 'tail_prompts': []}

        mode = 'head'
        for line in lines:
            if mode == 'head':
                if re.match(r'^\d+:', line):
                    mode = 'mapp'
                else:
                    data['head_prompts'].append(line)

            if mode == 'mapp':
                match = re.match(r'^(\d+): (.+)$', line)
                if match:
                    frame, prompt = match.groups()
                    frame_num = int(frame)
                    assert frame_num < params.video_length, (
                        f"Invalid prompt travel frame number: {frame_num} >= video_length ({params.video_length})"
                    )
                    data['mapp_prompts'][frame_num] = prompt
                else:
                    mode = 'tail'

            if mode == 'tail':
                data['tail_prompts'].append(line)

        if data['mapp_prompts']:
            logger.info("You are using prompt travel.")
            self.prompt_map = {}
            prompt_list = []
            last_frame = 0
            current_prompt = ''
            for frame, prompt in data['mapp_prompts'].items():
                prompt_list += [current_prompt for _ in range(last_frame, frame)]
                last_frame = frame
                current_prompt = (
                    f"{', '.join(data['head_prompts'])}, {prompt}, {', '.join(data['tail_prompts'])}"
                )
                self.prompt_map[frame] = current_prompt

            prompt_list += [current_prompt for _ in range(last_frame, p.batch_size)]
            assert len(prompt_list) == p.batch_size, (
                f"prompt_list length {len(prompt_list)} != batch_size {p.batch_size}"
            )

            self.original_prompt = p.prompt
            p.prompt = prompt_list * p.n_iter  # repeat for n_iter

    def single_cond(self, center_frame: int, video_length: int, cond, closed_loop=False):
        """Interpolate conditioning for a single frame using SLERP."""
        if not self.prompt_map:
            return cond[center_frame] if isinstance(cond, torch.Tensor) else {k: v[center_frame] for k, v in cond.items()}

        keys = list(self.prompt_map.keys())
        key_prev, key_next = (keys[-1], keys[0]) if closed_loop else (keys[0], keys[-1])

        for k in keys:
            if k > center_frame:
                key_next = k
                break
            key_prev = k

        dist_prev = (center_frame - key_prev) % video_length
        dist_next = (key_next - center_frame) % video_length

        if key_prev == key_next or dist_prev + dist_next == 0:
            return cond[key_prev] if isinstance(cond, torch.Tensor) else {k: v[key_prev] for k, v in cond.items()}

        rate = dist_prev / (dist_prev + dist_next)
        if isinstance(cond, torch.Tensor):
            return AnimateDiffPromptSchedule.slerp(cond[key_prev], cond[key_next], rate)
        else:
            return {k: AnimateDiffPromptSchedule.slerp(v[key_prev], v[key_next], rate) for k, v in cond.items()}

    def multi_cond(self, cond, closed_loop=False):
        """Interpolate conditioning for all frames."""
        if self.prompt_map is None:
            return cond

        if isinstance(cond, torch.Tensor):
            cond_list = [self.single_cond(i, cond.shape[0], cond, closed_loop) for i in range(cond.shape[0])]
            return torch.stack(cond_list).to(cond.dtype).to(cond.device)
        else:
            from modules.prompt_parser import DictWithShape
            cond_list = {k: [] for k in cond.keys()}
            for i in range(next(iter(cond.values())).shape[0]):
                frame_cond = self.single_cond(i, next(iter(cond.values())).shape[0], cond, closed_loop)
                for k, v in frame_cond.items():
                    cond_list[k].append(v)
            return DictWithShape({k: torch.stack(v).to(cond[k].dtype).to(cond[k].device) for k, v in cond_list.items()}, None)

    @staticmethod
    def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
        """Spherical linear interpolation between two vectors."""
        u0 = v0 / v0.norm()
        u1 = v1 / v1.norm()
        dot = (u0 * u1).sum()
        if abs(dot) > DOT_THRESHOLD:
            return (1.0 - t) * v0 + t * v1
        omega = dot.acos()
        return (((1.0 - t) * omega).sin() * v0 + (t * omega).sin() * v1) / omega.sin()
