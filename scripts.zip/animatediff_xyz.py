# animatediff_xyz.py

from types import ModuleType
from typing import Optional, Any, Callable
from modules import scripts
from scripts.animatediff_logger import logger_animatediff as logger

xyz_attrs: dict[str, Any] = {}


def patch_xyz():
    xyz_module = find_xyz_module()
    if xyz_module is None:
        logger.warning("[AnimateDiff] XYZ module not found.")
        return

    MODULE = "[AnimateDiff]"

    xyz_module.axis_options.extend([
        xyz_module.AxisOption(label=f"{MODULE} Enabled",
                              type=str_to_bool,
                              apply=apply_state("enable"),
                              choices=choices_bool),
        xyz_module.AxisOption(label=f"{MODULE} Motion Module",
                              type=str,
                              apply=apply_state("model")),
        xyz_module.AxisOption(label=f"{MODULE} Video length",
                              type=num_or_float,
                              apply=apply_state("video_length")),
        xyz_module.AxisOption(label=f"{MODULE} FPS",
                              type=num_or_float,
                              apply=apply_state("fps")),
        xyz_module.AxisOption(label=f"{MODULE} Use main seed",
                              type=str_to_bool,
                              apply=apply_state("use_main_seed"),
                              choices=choices_bool),
        xyz_module.AxisOption(label=f"{MODULE} Closed loop",
                              type=str,
                              apply=apply_state("closed_loop"),
                              choices=lambda: ["N", "R-P", "R+P", "A"]),
        xyz_module.AxisOption(label=f"{MODULE} Batch size",
                              type=num_or_float,
                              apply=apply_state("batch_size")),
        xyz_module.AxisOption(label=f"{MODULE} Stride",
                              type=num_or_float,
                              apply=apply_state("stride")),
        xyz_module.AxisOption(label=f"{MODULE} Overlap",
                              type=num_or_float,
                              apply=apply_state("overlap")),
        xyz_module.AxisOption(label=f"{MODULE} Interp",
                              type=str_to_bool,
                              apply=apply_state("interp"),
                              choices=choices_bool),
        xyz_module.AxisOption(label=f"{MODULE} Interp X",
                              type=num_or_float,
                              apply=apply_state("interp_x")),
        xyz_module.AxisOption(label=f"{MODULE} Video path",
                              type=str,
                              apply=apply_state("video_path")),
        xyz_module.AxisOptionImg2Img(label=f"{MODULE} Latent power",
                                     type=num_or_float,
                                     apply=apply_state("latent_power")),
        xyz_module.AxisOptionImg2Img(label=f"{MODULE} Latent scale",
                                     type=num_or_float,
                                     apply=apply_state("latent_scale")),
        xyz_module.AxisOptionImg2Img(label=f"{MODULE} Latent power last",
                                     type=num_or_float,
                                     apply=apply_state("latent_power_last")),
        xyz_module.AxisOptionImg2Img(label=f"{MODULE} Latent scale last",
                                     type=num_or_float,
                                     apply=apply_state("latent_scale_last")),
    ])


def apply_state(key: str, key_map: Optional[dict] = None) -> Callable:
    def callback(_p, value, _vs):
        if key_map is not None:
            value = key_map.get(value, value)
        xyz_attrs[key] = value
    return callback


def str_to_bool(s: str) -> Optional[bool]:
    if s.lower() in ("true", "1"):
        return True
    if s.lower() in ("false", "0"):
        return False
    return None


def num_or_float(s: str) -> float:
    try:
        return int(s)
    except ValueError:
        return float(s)


def choices_bool() -> list[str]:
    return ["False", "True"]


def find_xyz_module() -> Optional[ModuleType]:
    for data in scripts.scripts_data:
        if data.script_class.__module__ in {"xyz_grid.py", "xy_grid.py"} and hasattr(data, "module"):
            return data.module
    return None
