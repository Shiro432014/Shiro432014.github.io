import gradio as gr
from modules import shared


def get_supported_save_formats() -> list[str]:
    """Возвращает список поддерживаемых форматов сохранения из animatediff_ui."""
    try:
        from scripts.animatediff_ui import supported_save_formats
        return supported_save_formats
    except ImportError:
        # Если UI ещё не инициализирован, возвращаем базовые значения
        return ["GIF", "PNG"]


def on_ui_settings():
    section = ("animatediff", "AnimateDiff")
    s3_section = ("animatediff", "AnimateDiff AWS")

    # === Основные настройки ===
    shared.opts.add_option(
        "animatediff_disable_control_wrapper",
        shared.OptionInfo(
            default=False,
            label="Disable ControlNet wrapper for AnimateDiff (requires more VRAM)",
            component=gr.Checkbox,
            section=section
        )
    )
    shared.opts.add_option(
        "animatediff_control_batch_size",
        shared.OptionInfo(
            default=0,
            label="ControlNet batch size for AnimateDiff (default: 2 * context_batch_size)",
            component=gr.Slider,
            component_args={"minimum": 0, "maximum": 128, "step": 4},
            section=section,
        )
    )
    shared.opts.add_option(
        "animatediff_model_path",
        shared.OptionInfo(
            default=None,
            label="Path to save AnimateDiff motion modules",
            component=gr.Textbox,
            component_args={"placeholder": "Leave empty to use default path: extensions/sd-webui-animatediff/model"},
            section=section,
        )
    )
    shared.opts.add_option(
        "animatediff_default_save_formats",
        shared.OptionInfo(
            default=["GIF", "PNG"],
            label="Default Save Formats",
            component=gr.CheckboxGroup,
            component_args={"choices": get_supported_save_formats()},
            section=section
        ).needs_restart()
    )
    shared.opts.add_option(
        "animatediff_save_to_custom",
        shared.OptionInfo(
            default=True,
            label="Save frames to custom AnimateDiff folder",
            component=gr.Checkbox,
            section=section
        )
    )
    shared.opts.add_option(
        "animatediff_frame_extract_path",
        shared.OptionInfo(
            default=None,
            label="Path to save extracted frames",
            component=gr.Textbox,
            component_args={"placeholder": "Leave empty to use default path: tmp/animatediff-frames"},
            section=section
        )
    )
    shared.opts.add_option(
        "animatediff_frame_extract_remove",
        shared.OptionInfo(
            default=False,
            label="Always remove extracted frames after processing",
            component=gr.Checkbox,
            section=section
        )
    )
    shared.opts.add_option(
        "animatediff_default_frame_extract_method",
        shared.OptionInfo(
            default="ffmpeg",
            label="Default frame extraction method",
            component=gr.Radio,
            component_args={"choices": ["ffmpeg", "opencv"]},
            section=section
        )
    )

    # === Оптимизация видео/GIF ===
    shared.opts.add_option(
        "animatediff_optimize_gif_palette",
        shared.OptionInfo(
            default=False,
            label="Calculate optimal GIF palette to improve quality",
            component=gr.Checkbox,
            section=section
        )
    )
    shared.opts.add_option(
        "animatediff_optimize_gif_gifsicle",
        shared.OptionInfo(
            default=False,
            label="Optimize GIFs with gifsicle to reduce file size",
            component=gr.Checkbox,
            section=section
        )
    )
    shared.opts.add_option(
        "animatediff_mp4_crf",
        shared.OptionInfo(
            default=23,
            label="MP4 Quality (CRF)",
            component=gr.Slider,
            component_args={"minimum": 0, "maximum": 51, "step": 1},
            section=section
        )
    )
    shared.opts.add_option(
        "animatediff_mp4_preset",
        shared.OptionInfo(
            default="",
            label="MP4 Encoding Preset",
            component=gr.Dropdown,
            component_args={"choices": ["", 'veryslow', 'slower', 'slow', 'medium', 'fast', 'faster', 'veryfast', 'superfast', 'ultrafast']},
            section=section
        )
    )
    shared.opts.add_option(
        "animatediff_mp4_tune",
        shared.OptionInfo(
            default="",
            label="MP4 Tune encoding for content type",
            component=gr.Dropdown,
            component_args={"choices": ["", "film", "animation", "grain"]},
            section=section
        )
    )
    shared.opts.add_option(
        "animatediff_webp_quality",
        shared.OptionInfo(
            default=80,
            label="WebP Quality",
            component=gr.Slider,
            component_args={"minimum": 1, "maximum": 100, "step": 1},
            section=section
        )
    )
    shared.opts.add_option(
        "animatediff_webp_lossless",
        shared.OptionInfo(
            default=False,
            label="Save WebP in lossless format",
            component=gr.Checkbox,
            section=section
        )
    )

    # === Настройки S3 ===
    shared.opts.add_option(
        "animatediff_s3_enable",
        shared.OptionInfo(
            default=False,
            label="Enable storing files to S3-compatible object storage",
            component=gr.Checkbox,
            section=s3_section
        )
    )
    shared.opts.add_option(
        "animatediff_s3_host",
        shared.OptionInfo(default=None, label="S3 host", component=gr.Textbox, section=s3_section)
    )
    shared.opts.add_option(
        "animatediff_s3_port",
        shared.OptionInfo(default=None, label="S3 port", component=gr.Textbox, section=s3_section)
    )
    shared.opts.add_option(
        "animatediff_s3_access_key",
        shared.OptionInfo(default=None, label="S3 access key", component=gr.Textbox, section=s3_section)
    )
    shared.opts.add_option(
        "animatediff_s3_secret_key",
        shared.OptionInfo(default=None, label="S3 secret key", component=gr.Textbox, section=s3_section)
    )
    shared.opts.add_option(
        "animatediff_s3_storge_bucket",
        shared.OptionInfo(default=None, label="S3 bucket name", component=gr.Textbox, section=s3_section)
    )
