import os
from modules.paths import data_path
from modules.processing import StableDiffusionProcessing, StableDiffusionProcessingImg2Img
from scripts.animatediff_ui import AnimateDiffProcess
from scripts.animatediff_logger import logger_animatediff as logger


def update_infotext(p: StableDiffusionProcessing, params: AnimateDiffProcess):
    """Обновляет extra_generation_params для отображения AnimateDiff параметров."""
    if p.extra_generation_params is not None:
        p.extra_generation_params["AnimateDiff"] = params.get_dict(isinstance(p, StableDiffusionProcessingImg2Img))


def write_params_txt(info: str):
    """Записывает инфотекст в params.txt в data_path."""
    path = os.path.join(data_path, "params.txt")
    try:
        with open(path, "w", encoding="utf8") as file:
            file.write(info)
    except Exception as e:
        logger.warn(f"Failed to write params.txt: {e}")


def infotext_pasted(infotext, results):
    """Разбирает инфотекст AnimateDiff и обновляет results словарь."""
    if not isinstance(results, dict):
        logger.warn(f"Expected results to be dict, got {type(results)}")
        return

    for k, v in list(results.items()):
        if not k.startswith("AnimateDiff"):
            continue

        if not isinstance(v, str):
            logger.warn(f"Expected string value for {k}, got {type(v)}")
            continue

        try:
            for item in v.split(', '):
                if ': ' in item:
                    field, value = item.split(': ', 1)
                    results[f"AnimateDiff {field}"] = value
            results.pop(k, None)
        except Exception as e:
            logger.warn(f"Failed to parse infotext value:\n{v}")
            logger.warn(f"Exception: {e}")
        break
