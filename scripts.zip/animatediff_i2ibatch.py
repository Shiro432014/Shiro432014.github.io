from types import MethodType
from pathlib import Path
import os
import hashlib
import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError
import torch
import cv2

from modules import devices, processing, scripts, sd_samplers, shared
from modules.processing import StableDiffusionProcessingImg2Img
from scripts.animatediff_mm import mm_animatediff as motion_module
from scripts.animatediff_logger import logger_animatediff as logger
from scripts.animatediff_utils import get_animatediff_arg

# Локальные импорты для поддержки старого img2img
try:
    from scripts.animatediff_i2ibatch import img2img
except ImportError:
    img2img = shared

def animatediff_i2i_init(self, all_prompts, all_seeds, all_subseeds):
    self.extra_generation_params["Denoising strength"] = self.denoising_strength

    self.image_cfg_scale = self.image_cfg_scale if shared.sd_model.cond_stage_key == "edit" else None
    self.sampler = sd_samplers.create_sampler(self.sampler_name, self.sd_model)

    crop_regions = []
    paste_to = []
    masks_for_overlay = []
    image_masks = self.image_mask

    # обработка масок
    for idx, image_mask in enumerate(image_masks):
        image_mask = ImageOps.invert(image_mask) if self.inpainting_mask_invert else image_mask
        if self.mask_blur_x > 0:
            np_mask = np.array(image_mask)
            kernel_size = 2 * int(2.5 * self.mask_blur_x + 0.5) + 1
            np_mask = cv2.GaussianBlur(np_mask, (kernel_size, 1), self.mask_blur_x)
            image_mask = Image.fromarray(np_mask)
        if self.mask_blur_y > 0:
            np_mask = np.array(image_mask)
            kernel_size = 2 * int(2.5 * self.mask_blur_y + 0.5) + 1
            np_mask = cv2.GaussianBlur(np_mask, (1, kernel_size), self.mask_blur_y)
            image_mask = Image.fromarray(np_mask)
        image_masks[idx] = image_mask

    self.mask_for_overlay = masks_for_overlay[0] if masks_for_overlay else None
    if paste_to:
        self.paste_to = paste_to[0]
        self._animatediff_paste_to_full = paste_to

    # подготовка init images
    imgs = []
    for idx, img in enumerate(self.init_images):
        image = np.array(img).astype(np.float32) / 255.0
        image = np.moveaxis(image, 2, 0)
        imgs.append(image)

    batch_images = np.expand_dims(imgs[0], axis=0).repeat(self.batch_size, axis=0) if len(imgs) == 1 else np.array(imgs)
    image = torch.from_numpy(batch_images).to(shared.device, dtype=devices.dtype_vae)

    # создание латентов
    self.init_latent = processing.images_tensor_to_samples(image, None, self.sd_model)
    devices.torch_gc()


def animatediff_i2i_batch(p: StableDiffusionProcessingImg2Img, input_dir: str, output_dir: str, inpaint_mask_dir: str,
                           args, to_scale=False, scale_by=1.0, use_png_info=False, png_info_props=None, png_info_dir=None):
    ad_params = get_animatediff_arg(p)
    if not ad_params.enable:
        return img2img.original_i2i_batch(p, input_dir, output_dir, inpaint_mask_dir, args, to_scale, scale_by, use_png_info, png_info_props, png_info_dir)
    ad_params.is_i2i_batch = True
    if not ad_params.video_path and not ad_params.video_source:
        ad_params.video_path = input_dir

    output_dir = output_dir.strip()
    images = list(shared.walk_files(input_dir, allowed_extensions=(".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff")))

    # маски inpaint
    frame_images, frame_masks = [], []
    if inpaint_mask_dir:
        inpaint_masks = shared.listfiles(inpaint_mask_dir)
        if len(inpaint_masks) > 1:
            p.init = MethodType(animatediff_i2i_init, p)
        for i, image_path in enumerate(images):
            img = Image.open(image_path)
            frame_images.append(ImageOps.exif_transpose(img))
            if inpaint_masks:
                mask_image = Image.open(inpaint_masks[min(i, len(inpaint_masks)-1)])
                frame_masks.append(mask_image)
                p.image_mask = mask_image

    p.init_images = frame_images
    if frame_masks:
        p.image_mask = frame_masks

    # обработка batch
    proc = scripts.scripts_img2img.run(p, *args)
    return proc


def animatediff_hook_i2i_batch():
    if getattr(img2img, "original_i2i_batch", None) is None:
        logger.info("AnimateDiff Hooking i2i_batch")
        img2img.original_i2i_batch = img2img.process_batch
        img2img.process_batch = animatediff_i2i_batch


def animatediff_unhook_i2i_batch():
    if getattr(img2img, "original_i2i_batch", None) is not None:
        logger.info("AnimateDiff Unhooking i2i_batch")
        img2img.process_batch = img2img.original_i2i_batch
        img2img.original_i2i_batch = None
