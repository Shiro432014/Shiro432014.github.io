# animatediff_mm.py
from scripts.animatediff_logger import logger_animatediff as logger

# Заглушка для Motion Module
class MotionModule:
    def __init__(self):
        self.name = "AnimateDiff Motion Module"

    def process(self, frames):
        logger.info("[AnimateDiff] MotionModule: processing frames...")
        return frames  # просто возвращаем без изменений

mm_animatediff = MotionModule()
