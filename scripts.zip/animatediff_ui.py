import os
import cv2
import subprocess
import gradio as gr
from typing import List
from modules import shared
from scripts.animatediff_mm import mm_animatediff as motion_module

# Поддерживаемые форматы сохранения
supported_save_formats = ["GIF", "MP4", "WEBP", "WEBM", "PNG", "TXT"]

class ToolButton(gr.Button, gr.components.FormComponent):
    """Small button with single emoji as text, fits inside gradio forms"""
    def __init__(self, **kwargs):
        super().__init__(variant="tool", **kwargs)

    def get_block_name(self):
        return "button"

class AnimateDiffProcess:
    def __init__(
        self,
        model="mm_sd15_v3.safetensors",
        enable=False,
        video_length=0,
        fps=8,
        loop_number=0,
        closed_loop='R-P',
        batch_size=16,
        stride=1,
        overlap=-1,
        format=None,
        interp='Off',
        interp_x=10,
        video_source=None,
        video_path='',
        mask_path='',
        latent_power=1,
        latent_scale=32,
        last_frame=None,
        latent_power_last=1,
        latent_scale_last=32,
        request_id='',
    ):
        self.model = model
        self.enable = enable
        self.video_length = video_length
        self.fps = fps
        self.loop_number = loop_number
        self.closed_loop = closed_loop
        self.batch_size = batch_size
        self.stride = stride
        self.overlap = overlap
        self.format = format or shared.opts.data.get("animatediff_default_save_formats", ["GIF", "PNG"])
        self.interp = interp
        self.interp_x = interp_x
        self.video_source = video_source
        self.video_path = video_path
        self.mask_path = mask_path
        self.latent_power = latent_power
        self.latent_scale = latent_scale
        self.last_frame = last_frame
        self.latent_power_last = latent_power_last
        self.latent_scale_last = latent_scale_last
        self.request_id = request_id
        self.video_default = False
        self.is_i2i_batch = False
        self.prompt_scheduler = None

    def get_list(self, is_img2img: bool):
        return list(vars(self).values())[:(20 if is_img2img else 15)]

    def get_param_names(self, is_img2img: bool):
        preserve = ["model", "enable", "video_length", "fps", "loop_number", "closed_loop", "batch_size", "stride", "overlap", "format", "interp", "interp_x"]
        if is_img2img:
            preserve.extend(["latent_power", "latent_power_last", "latent_scale", "latent_scale_last"])
        return preserve

    def _check(self):
        assert self.video_length >= 0 and self.fps > 0, "Video length and FPS should be positive."
        assert not set(supported_save_formats[:-1]).isdisjoint(self.format), "At least one saving format should be selected."

class AnimateDiffUiGroup:
    txt2img_submit_button = None
    img2img_submit_button = None
    animatediff_ui_group = []

    def __init__(self):
        self.params = AnimateDiffProcess()
        AnimateDiffUiGroup.animatediff_ui_group.append(self)

    def get_model_list(self):
        model_dir = motion_module.get_model_dir()
        if not os.path.isdir(model_dir):
            os.makedirs(model_dir, exist_ok=True)

        def get_sd_rm_tag():
            if shared.sd_model.is_sdxl:
                return ["sd1"]
            elif shared.sd_model.is_sd2:
                return ["sd1, xl"]
            elif shared.sd_model.is_sd1:
                return ["xl"]
            return []

        return [f for f in os.listdir(model_dir) if f != ".gitkeep" and not any(tag in f for tag in get_sd_rm_tag())]

    def refresh_models(self, current_value):
        new_model_list = self.get_model_list()
        if current_value in new_model_list:
            selected = current_value
        elif new_model_list:
            selected = new_model_list[0]
        else:
            selected = None
        return gr.Dropdown.update(choices=new_model_list, value=selected)

    def render(self, is_img2img: bool, infotext_fields, paste_field_names):
        elemid_prefix = "img2img-ad-" if is_img2img else "txt2img-ad-"
        with gr.Accordion("AnimateDiff", open=False):
            gr.Markdown(value="Please click [this link](https://github.com/continue-revolution/sd-webui-animatediff/blob/forge/master/docs/how-to-use.md#parameters) to read the documentation of each parameter.")
            with gr.Row():
                model_list = self.get_model_list()
                self.params.model = gr.Dropdown(
                    choices=model_list,
                    value=self.params.model if self.params.model in model_list else (model_list[0] if model_list else None),
                    label="Motion module",
                    type="value",
                    elem_id=f"{elemid_prefix}motion-module",
                )
                refresh_model = ToolButton(value="\U0001f504")
                refresh_model.click(
                    fn=lambda val: self.refresh_models(val),
                    inputs=[self.params.model],
                    outputs=[self.params.model]
                )

            self.params.format = gr.CheckboxGroup(
                choices=supported_save_formats,
                label="Save format",
                type="value",
                elem_id=f"{elemid_prefix}save-format",
                value=self.params.format,
            )

            with gr.Row():
                self.params.enable = gr.Checkbox(value=self.params.enable, label="Enable AnimateDiff", elem_id=f"{elemid_prefix}enable")
                self.params.video_length = gr.Number(minimum=0, value=self.params.video_length, label="Number of frames", precision=0, elem_id=f"{elemid_prefix}video-length")
                self.params.fps = gr.Number(value=self.params.fps, label="FPS", precision=0, elem_id=f"{elemid_prefix}fps")
                self.params.loop_number = gr.Number(minimum=0, value=self.params.loop_number, label="Display loop number", precision=0, elem_id=f"{elemid_prefix}loop-number")

            with gr.Row():
                self.params.closed_loop = gr.Radio(choices=["N", "R-P", "R+P", "A"], value=self.params.closed_loop, label="Closed loop", elem_id=f"{elemid_prefix}closed-loop")
                self.params.batch_size = gr.Slider(minimum=1, maximum=32, value=self.params.batch_size, label="Context batch size", step=1, precision=0, elem_id=f"{elemid_prefix}batch-size")
                self.params.stride = gr.Number(minimum=1, value=self.params.stride, label="Stride", precision=0, elem_id=f"{elemid_prefix}stride")
                self.params.overlap = gr.Number(minimum=-1, value=self.params.overlap, label="Overlap", precision=0, elem_id=f"{elemid_prefix}overlap")

            with gr.Row():
                self.params.interp = gr.Radio(choices=["Off", "FILM"], label="Frame Interpolation", elem_id=f"{elemid_prefix}interp-choice", value=self.params.interp)
                self.params.interp_x = gr.Number(value=self.params.interp_x, label="Interp X", precision=0, elem_id=f"{elemid_prefix}interp-x")

            self.params.video_source = gr.Video(value=self.params.video_source, label="Video source")

            def update_fps(video_source):
                if video_source:
                    cap = cv2.VideoCapture(video_source)
                    fps = int(cap.get(cv2.CAP_PROP_FPS)) if cap.isOpened() else int(self.params.fps.value)
                    cap.release()
                    return fps
                return int(self.params.fps.value)

            def update_frames(video_source):
                if video_source:
                    cap = cv2.VideoCapture(video_source)
                    frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) if cap.isOpened() else int(self.params.video_length.value)
                    cap.release()
                    return frames
                return int(self.params.video_length.value)

            self.params.video_source.change(update_fps, inputs=[self.params.video_source], outputs=[self.params.fps])
            self.params.video_source.change(update_frames, inputs=[self.params.video_source], outputs=[self.params.video_length])

            with gr.Row():
                self.params.video_path = gr.Textbox(value=self.params.video_path, label="Video path", elem_id=f"{elemid_prefix}video-path")
                self.params.mask_path = gr.Textbox(value=self.params.mask_path, label="Mask path", elem_id=f"{elemid_prefix}mask-path")

            if is_img2img:
                with gr.Accordion("I2V Traditional", open=False):
                    with gr.Row():
                        self.params.latent_power = gr.Slider(minimum=0.1, maximum=10, value=self.params.latent_power, step=0.1, label="Latent power", elem_id=f"{elemid_prefix}latent-power")
                        self.params.latent_scale = gr.Slider(minimum=1, maximum=128, value=self.params.latent_scale, label="Latent scale", elem_id=f"{elemid_prefix}latent-scale")
                        self.params.latent_power_last = gr.Slider(minimum=0.1, maximum=10, value=self.params.latent_power_last, step=0.1, label="Optional latent power for last frame", elem_id=f"{elemid_prefix}latent-power-last")
                        self.params.latent_scale_last = gr.Slider(minimum=1, maximum=128, value=self.params.latent_scale_last, label="Optional latent scale for last frame", elem_id=f"{elemid_prefix}latent-scale-last")
                    self.params.last_frame = gr.Image(label="Optional last frame. Leave it blank if you do not need one.", type="pil")

        # Set up controls to be copy-pasted using infotext
        fields = self.params.get_param_names(is_img2img)
        infotext_fields.extend((getattr(self.params, field), f"AnimateDiff {field}") for field in fields)
        paste_field_names.extend(f"AnimateDiff {field}" for field in fields)

        return self.register_unit(is_img2img)

    def register_unit(self, is_img2img: bool):
        unit = gr.State(value=self.params)
        submit_button = AnimateDiffUiGroup.img2img_submit_button if is_img2img else AnimateDiffUiGroup.txt2img_submit_button

        if submit_button:
            submit_button.click(
                fn=lambda *args: AnimateDiffProcess(*args),
                inputs=self.params.get_list(is_img2img),
                outputs=[unit],
                queue=False,
            )
        return unit

    @staticmethod
    def on_after_component(component, **_kwargs):
        elem_id = getattr(component, "elem_id", None)

        if elem_id == "txt2img_generate":
            AnimateDiffUiGroup.txt2img_submit_button = component
            return

        if elem_id == "img2img_generate":
            AnimateDiffUiGroup.img2img_submit_button = component
            return

        if elem_id == "setting_sd_model_checkpoint":
            for group in AnimateDiffUiGroup.animatediff_ui_group:
                component.change(
                    fn=lambda value, g=group: g.refresh_models(value),
                    inputs=[group.params.model],
                    outputs=[group.params.model],
                    queue=False,
                )
