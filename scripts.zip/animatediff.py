# animatediff.py
import os
from pathlib import Path

from modules import shared
from modules.processing import StableDiffusionProcessing
from scripts.animatediff_logger import logger_animatediff as logger

# Утилиты
from scripts.animatediff_utils import generate_random_hash, ffmpeg_extract_frames, cv2_extract_frames, get_animatediff_arg, get_controlnet_units

def extract_frames_from_video(params):
    """Extract frames from video for AnimateDiff"""
    assert params.video_source, "You need to specify a video source."
    base_path = shared.opts.data.get(
        "animatediff_frame_extract_path",
        f"{shared.data_path}/tmp/animatediff-frames"
    )
    params.video_path = os.path.join(
        base_path,
        f"{Path(params.video_source).stem}-{generate_random_hash()}"
    )
    try:
        method = shared.opts.data.get("animatediff_default_frame_extract_method", "ffmpeg")
        if method == "opencv":
            cv2_extract_frames(params.video_source, params.video_path)
        else:
            ffmpeg_extract_frames(params.video_source, params.video_path)
    except Exception as e:
        logger.error(f"[AnimateDiff] Error extracting frames via ffmpeg: {e}, falling back to OpenCV.")
        cv2_extract_frames(params.video_source, params.video_path)
