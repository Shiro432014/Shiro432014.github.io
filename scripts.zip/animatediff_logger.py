import copy
import logging
import sys
from modules import shared

class ColoredFormatter(logging.Formatter):
    COLORS = {
        "DEBUG": "\033[0;36m",     # CYAN
        "INFO": "\033[0;32m",      # GREEN
        "WARNING": "\033[0;33m",   # YELLOW
        "ERROR": "\033[0;31m",     # RED
        "CRITICAL": "\033[0;37;41m", # WHITE ON RED
        "RESET": "\033[0m",
    }

    def format(self, record):
        colored_record = copy.copy(record)
        levelname = colored_record.levelname
        seq = self.COLORS.get(levelname, self.COLORS["RESET"])
        colored_record.levelname = f"{seq}{levelname}{self.COLORS['RESET']}"
        return super().format(colored_record)


def create_animatediff_logger():
    logger = logging.getLogger("AnimateDiff")
    logger.propagate = False

    # Добавляем обработчик, если ещё нет
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(
            ColoredFormatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        )
        logger.addHandler(handler)

    # Устанавливаем уровень логирования
    loglevel_string = getattr(shared.cmd_opts, "loglevel", "INFO") or "INFO"
    loglevel = getattr(logging, loglevel_string.upper(), logging.INFO)
    logger.setLevel(loglevel)
    
    return logger


# Создаем глобальный логгер для всех модулей AnimateDiff
logger_animatediff = create_animatediff_logger()
