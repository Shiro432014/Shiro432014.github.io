# animatediff_infv2v.py
from scripts.animatediff_ui import AnimateDiffProcess
from scripts.animatediff_logger import logger_animatediff as logger

class AnimateDiffInfV2V:
    def __init__(self, process: AnimateDiffProcess):
        self.process = process
        logger.info("[AnimateDiff] InfV2V initialized")

    def run(self):
        logger.info("[AnimateDiff] InfV2V running...")
        # здесь добавьте логику инференса
