# animatediff_utils.py
import os
import cv2
import subprocess
from pathlib import Path
from modules.processing import StableDiffusionProcessing
from scripts.animatediff_logger import logger_animatediff as logger

def generate_random_hash(length=8):
    import hashlib
    import secrets
    random_data = secrets.token_bytes(32)
    hash_hex = hashlib.sha256(random_data).hexdigest()
    return hash_hex[:length] if length <= len(hash_hex) else hash_hex

def get_animatediff_arg(p: StableDiffusionProcessing):
    if not p.scripts:
        return None
    for script in p.scripts.alwayson_scripts:
        if script.title().lower() == "animatediff":
            arg = p.script_args[script.args_from]
            if isinstance(arg, dict):
                from scripts.animatediff_ui import AnimateDiffProcess
                arg = AnimateDiffProcess(**arg)
                p.script_args[script.args_from] = arg
            return arg
    return None

def get_controlnet_units(p: StableDiffusionProcessing):
    if not p.scripts:
        return []
    for script in p.scripts.alwayson_scripts:
        if script.title().lower() == "controlnet":
            cn_units = p.script_args[script.args_from:script.args_to]
            if p.is_api and len(cn_units) > 0 and isinstance(cn_units[0], dict):
                from lib_controlnet.external_code import ControlNetUnit
                from lib_controlnet.enums import InputMode
                cn_units = [ControlNetUnit.from_dict(u) for u in cn_units]
                for u in cn_units:
                    if u.image is None:
                        u.input_mode = InputMode.BATCH
                p.script_args[script.args_from:script.args_to] = cn_units
            return [x for x in cn_units if getattr(x, "enabled", True)] if not p.is_api else cn_units
    return []

def ffmpeg_extract_frames(source_video: str, output_dir: str, extract_key: bool = False):
    command = ["ffmpeg", "-i", source_video]
    if extract_key:
        command += ["-vf", "select='eq(pict_type,I)'", "-vsync", "vfr"]
    else:
        command += ["-filter:v", "mpdecimate=hi=64*200:lo=64*50:frac=0.33,setpts=N/FRAME_RATE/TB"]
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    command += ["-qscale:v", "1", "-qmin", "1", "-c:a", "copy", os.path.join(output_dir, '%09d.jpg')]
    logger.info(f"[AnimateDiff] Extracting frames via ffmpeg: {source_video} -> {output_dir}")
    subprocess.run(command, check=True)

def cv2_extract_frames(source_video: str, output_dir: str):
    logger.info(f"[AnimateDiff] Extracting frames via OpenCV: {source_video} -> {output_dir}")
    cap = cv2.VideoCapture(source_video)
    frame_count = 0
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        cv2.imwrite(os.path.join(output_dir, f"{frame_count:09d}.png"), frame)
        frame_count += 1
    cap.release()
