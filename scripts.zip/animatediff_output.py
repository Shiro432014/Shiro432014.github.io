import os
import glob
import base64
import datetime
import shutil
from pathlib import Path
import logging

import numpy as np
import imageio
from PIL import Image, PngImagePlugin, features
import piexif

from modules import shared
from scripts.animatediff_ui import AnimateDiffProcess
from scripts.animatediff_mm import mm_animatediff as motion_module

logger = logging.getLogger("AnimateDiffOutput")


class AnimateDiffOutput:
    def output(self, p: "StableDiffusionProcessing", res: "Processed", params: AnimateDiffProcess):
        video_paths = []
        first_frames = []
        from_xyz = any("xyz_grid" in frame.filename for frame in traceback.extract_stack())
        logger.info(f"Saving output formats: {', '.join(params.format)}")

        date = datetime.datetime.now().strftime('%Y-%m-%d')
        output_dir = Path(f"{p.outpath_samples}/AnimateDiff/{date}")
        output_dir.mkdir(parents=True, exist_ok=True)

        step = params.video_length if params.video_length > params.batch_size else params.batch_size

        for i in range(res.index_of_first_image, len(res.images), step):
            frame_list = [img.copy() for img in res.images[i:i + params.video_length]]

            if from_xyz:
                first_frames.append(res.images[i].copy())

            seq = images.get_next_sequence_number(output_dir, "")
            filename_suffix = f"-{params.request_id}" if params.request_id else ""
            filename = f"{seq:05}-{res.all_seeds[(i - res.index_of_first_image)]}{filename_suffix}"
            video_path_prefix = output_dir / filename

            frame_list = self._add_reverse(params, frame_list)
            frame_list = self._interp(p, params, frame_list, filename)
            video_paths += self._save(params, frame_list, video_path_prefix, res, i)

        if not video_paths:
            return

        # Replace images with video paths or base64-encoded videos
        if not p.is_api:
            res.images = video_paths
        else:
            encoded_videos = self._encode_video_to_b64(video_paths)
            res.images = encoded_videos + (frame_list if 'Frame' in params.format else [])

        if from_xyz:
            res.images = first_frames

        if shared.opts.data.get("animatediff_frame_extract_remove", False):
            self._remove_frame_extract(params)

    def _remove_frame_extract(self, params: AnimateDiffProcess):
        if params.video_source and params.video_path and Path(params.video_path).exists():
            logger.info(f"Removing extracted frames from {params.video_path}")
            shutil.rmtree(params.video_path)

    def _add_reverse(self, params: AnimateDiffProcess, frame_list: list):
        if params.video_length <= params.batch_size and params.closed_loop in ['A']:
            frame_list_rev = frame_list[::-1]
            if frame_list_rev:
                frame_list_rev.pop(0)
            if frame_list_rev:
                frame_list_rev.pop(-1)
            return frame_list + frame_list_rev
        return frame_list

    def _interp(self, p, params: AnimateDiffProcess, frame_list: list, filename: str):
        if params.interp != 'FILM':
            return frame_list

        try:
            from deforum_helpers.frame_interpolation import calculate_frames_to_add, check_and_download_film_model
            from film_interpolation.film_inference import run_film_interp_infer
        except ImportError:
            logger.error("Deforum not found. Install from https://github.com/deforum-art/deforum-for-automatic1111-webui.git")
            return frame_list

        import modules.paths as ph
        tmp_folder = Path(f"{p.outpath_samples}/AnimateDiff/tmp")
        input_folder = tmp_folder / "input"
        input_folder.mkdir(parents=True, exist_ok=True)

        # Save original frames
        for idx, frame in enumerate(frame_list):
            imageio.imwrite(str(input_folder / f"{idx:05}.png"), frame)

        # Film model path
        film_model_folder = Path(ph.models_path) / 'Deforum/film_interpolation'
        film_model_folder.mkdir(parents=True, exist_ok=True)
        film_model_name = 'film_net_fp16.pt'
        film_model_path = film_model_folder / film_model_name
        check_and_download_film_model(film_model_name, film_model_folder)

        film_in_between_frames_count = calculate_frames_to_add(len(frame_list), params.interp_x)
        save_folder = tmp_folder / filename
        save_folder.mkdir(parents=True, exist_ok=True)

        run_film_interp_infer(
            model_path=film_model_path,
            input_folder=input_folder,
            save_folder=save_folder,
            inter_frames=film_in_between_frames_count
        )

        # Load interpolated frames
        interp_frame_paths = sorted(save_folder.glob('*.png'))
        frame_list = [Image.open(f).copy() for f in interp_frame_paths]

        if "PNG" in params.format:
            params.force_save_to_custom = True

        # Remove tmp folder
        try:
            shutil.rmtree(tmp_folder)
        except OSError as e:
            logger.warning(f"Error removing tmp folder: {e}")

        return frame_list

    def _save(self, params: AnimateDiffProcess, frame_list: list, video_path_prefix: Path, res, index: int):
        video_paths = []
        video_array = [np.array(v) for v in frame_list]
        infotext = res.infotexts[index]
        s3_enable = shared.opts.data.get("animatediff_s3_enable", False)
        use_infotext = shared.opts.enable_pnginfo and infotext is not None

        # Save PNG frames
        if "PNG" in params.format and (shared.opts.data.get("animatediff_save_to_custom", True) or getattr(params, "force_save_to_custom", False)):
            video_path_prefix.mkdir(parents=True, exist_ok=True)
            for i, frame in enumerate(frame_list):
                png_filename = video_path_prefix / f"{i:05}.png"
                png_info = PngImagePlugin.PngInfo()
                png_info.add_text('parameters', infotext)
                imageio.imwrite(str(png_filename), frame, pnginfo=png_info)

        # Save GIF
        if "GIF" in params.format:
            video_path_gif = str(video_path_prefix) + ".gif"
            video_paths.append(video_path_gif)
            imageio.mimsave(video_path_gif, video_array, fps=params.fps, loop=params.loop_number, format='GIF')

        # Save MP4
        if "MP4" in params.format:
            video_path_mp4 = str(video_path_prefix) + ".mp4"
            video_paths.append(video_path_mp4)
            imageio.mimsave(video_path_mp4, video_array, fps=params.fps, format='FFMPEG', codec='libx264')

        # Save TXT
        if "TXT" in params.format and infotext is not None:
            video_path_txt = str(video_path_prefix) + ".txt"
            with open(video_path_txt, "w", encoding="utf8") as f:
                f.write(infotext + "\n")

        # Save to S3 if enabled
        if s3_enable:
            for vp in video_paths:
                self._save_to_s3_storage(vp)

        return video_paths

    def _encode_video_to_b64(self, paths):
        videos = []
        for path in paths:
            with open(path, "rb") as f:
                videos.append(base64.b64encode(f.read()).decode("utf-8"))
        return videos

    def _install_requirement_if_absent(self, lib):
        import launch
        if not launch.is_installed(lib):
            launch.run_pip(f"install {lib}", f"animatediff requirement: {lib}")

    def _exist_bucket(self, s3_client, bucketname):
        try:
            s3_client.head_bucket(Bucket=bucketname)
            return True
        except Exception:
            return False

    def _save_to_s3_storage(self, file_path):
        self._install_requirement_if_absent("boto3")
        import boto3
        host = shared.opts.data.get("animatediff_s3_host", "127.0.0.1")
        port = shared.opts.data.get("animatediff_s3_port", "9001")
        access_key = shared.opts.data.get("animatediff_s3_access_key", "")
        secret_key = shared.opts.data.get("animatediff_s3_secret_key", "")
        bucket = shared.opts.data.get("animatediff_s3_storge_bucket", "")
        client = boto3.client(
            service_name='s3',
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            endpoint_url=f"http://{host}:{port}",
        )

        if not os.path.exists(file_path):
            return

        date = datetime.datetime.now().strftime("%Y-%m-%d")
        if not self._exist_bucket(client, bucket):
            client.create_bucket(Bucket=bucket)

        filename = os.path.basename(file_path)
        target_path = f"{date}/{filename}"
        client.upload_file(file_path, bucket, target_path)
        logger.info(f"{file_path} saved to S3 bucket: {bucket}")
        return f"http://{host}:{port}/{bucket}/{target_path}"
